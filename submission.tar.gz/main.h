#ifndef MAIN_H
#define MAIN_H

#include "gba.h"

// TODO: Create any necessary structs

typedef struct {
  int row;
  int col;
  int width;
  int height;
} Swatter;

typedef struct {
  int row;
  int col;
  int width;
  int height;
  int active;
} Fly;

#endif
