David Yoonmin Lee  
HW06: Fly Swatter Game  

Game Description:  
Fly Swatter Game is a GBA game where the player controls a swatter using the directional buttons to move across the screen.  
A fly randomly spawns on the playfield, and the objective is to move the swatter over the fly and press the A button (X on the keyboard) to swat it.  

The player has 30 seconds to score as many points as possible.  
The game ends when time runs out. If the player scores 5 or more points, a win screen appears.  
Otherwise, a lose screen is displayed.  

Press Select (Backspace on the keyboard) at any time to reset the game.