/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 fly fly.png 
 * Time-stamp: Wednesday 04/02/2025, 20:05:16
 * 
 * Image Information
 * -----------------
 * fly.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLY_H
#define FLY_H

extern const unsigned short flyObj[256];
#define FLY_SIZE 512
#define FLY_LENGTH 256
#define FLY_WIDTH 16
#define FLY_HEIGHT 16

#endif

