/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 destination destination.png 
 * Time-stamp: Wednesday 04/02/2025, 20:24:52
 * 
 * Image Information
 * -----------------
 * destination.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DESTINATION_H
#define DESTINATION_H

extern const unsigned short destination[256];
#define DESTINATION_SIZE 512
#define DESTINATION_LENGTH 256
#define DESTINATION_WIDTH 16
#define DESTINATION_HEIGHT 16

#endif

