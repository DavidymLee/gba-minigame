/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 play play.png 
 * Time-stamp: Wednesday 04/02/2025, 00:52:53
 * 
 * Image Information
 * -----------------
 * play.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAY_H
#define PLAY_H

extern const unsigned short play[38400];
#define PLAY_SIZE 76800
#define PLAY_LENGTH 38400
#define PLAY_WIDTH 240
#define PLAY_HEIGHT 160

#endif

