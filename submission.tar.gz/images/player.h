/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 player player.png 
 * Time-stamp: Wednesday 04/02/2025, 00:52:59
 * 
 * Image Information
 * -----------------
 * player.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_H
#define PLAYER_H

extern const unsigned short player[256];
#define PLAYER_SIZE 512
#define PLAYER_LENGTH 256
#define PLAYER_WIDTH 16
#define PLAYER_HEIGHT 16

#endif

