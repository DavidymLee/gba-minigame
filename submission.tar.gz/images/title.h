/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 title title.png 
 * Time-stamp: Wednesday 04/02/2025, 02:58:32
 * 
 * Image Information
 * -----------------
 * title.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short title[38400];
#define TITLE_SIZE 76800
#define TITLE_LENGTH 38400
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

